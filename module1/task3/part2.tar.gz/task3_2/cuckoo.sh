#!/bin/bash
PIPE="/tmp/run/cuckoo.pid"
LOG="cuckoo.log"

if [ ! -p "$PIPE" ]; then
	mkdir -p "$(dirname "$PIPE")"
	mkfifo "$PIPE"
fi
trap 'echo  "$(date "+%d.%m.%Y %H:%M:%S") Shutdown!" >> "$LOG"; exit 0' SIGINT
echo "$(date '+%d.%m.%Y %H:%M:%S') Startup!" >> "$LOG"
format_str="^([^[]+)\[([0-9]+)\]: how much time do i have\?"
while true; do
	if IFS= read -r line; then
		if [[ "$line" =~ $format_str ]]; then
			process_name="${BASH_REMATCH[1]}"
			pid="${BASH_REMATCH[2]}"
			N=$(( RANDOM %9 + 2))
			echo "$N" >> "/tmp/run/worker_${pid}.pipe"
			echo "$(date '+%d.%m.%Y %H:%M:%S') $process_name[$pid] $N" >> "$LOG" 
		fi
	fi
done < "$PIPE"
