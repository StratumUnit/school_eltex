#!/bin/bash

conf_file="observer.conf"

if [ ! -f "$conf_file" ]; then
	echo "Не найден файл конфигурации observer.conf"
	exit 1
fi

while IFS= read -r script; do
	if [ -z "$script" ]; then
		continue
	fi

	if ! grep -q -a "$script" /proc/[0-9]*/cmdline 2>/dev/null; then
		if [ -x "$script" ]; then

			nohup "$script" > /dev/null 2>&1 &
			last_pid=$!
			echo "$(date "+%d.%m.%Y %H:%M:%S") скрипт $script был перезапущен c pid $last_pid" >> "observer.log"
		else
			echo "$(date "+%d.%m.%Y %H:%M:%S") файл скрипта $script не найден" >> "observer.log"
		fi
	fi
done < "$conf_file"
