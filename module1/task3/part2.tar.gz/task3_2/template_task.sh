#!/bin/bash

full_name=$(basename "$0")
script_name="${full_name%.*}"
log_file="report_${script_name}.log"

if [ "$script_name" == "template_task" ]; then
	echo "я бригадир, сам не работаю"
	exit 1 
fi

pipe="/tmp/run/worker_$$.pipe"
mkfifo "$pipe"

if [ ! -f "$log_file" ]; then
	touch "$log_file"
fi

echo "$(date "+%d.%m.%Y %H:%M:%S") [$$] Скрипт запущен" >> "$log_file"
echo "${script_name}[$$]: how much time do i have?" >> /tmp/run/cuckoo.pid

read -r N < "$pipe"

sleep $N

echo "$(date "+%d.%m.%Y %H:%M:%S") [$$] Скрипт завершился, работал $N секунд" >> "$log_file"

rm "$pipe"
